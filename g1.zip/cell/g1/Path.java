package cell.g1;

import java.util.ArrayList;

public class Path implements Comparable{
	int length;
	ArrayList<Integer[]> locs;
	
	public void add(int[] loc){
		
	}

	@Override
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
}
